import React, {useState, useEffect} from 'react'
import { Link, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios'
import { registerRoute } from '../utils/APIRoutes';
import Loader from '../components/Loader.js';
function Register() {
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate()
    const [values, setValues]= useState({
        username: '',
        email: '',
        password: '',
        gender: '',
        city: '',
        reference: '',
        state: '',
        phone: ''
    })
    const toastOptions = {
        position: 'bottom-right',
        pauseOnHover: true,
        autoClose: 8000,
        draggable: true,
        theme: 'dark'
    }
    const handleSubmit = async (event)=>{
        event.preventDefault();
        if(handleValidation()){
            const {password, email, username,city,state,reference,phone} = values;
            setLoading(true);
            const  {data}  = await axios.post(registerRoute,{
             username,
             email,
             password,
             city,
             state,
             reference,
             phone
            })
            if(data.status === false){
                setLoading(false);
                toast.error(data.message, toastOptions)
            }
            if(data.status === true){
                setLoading(false);
                localStorage.setItem('user', JSON.stringify(data.user))
                navigate('/')
            }
        } 
    }
    const handleChange = (e) =>{
        setValues({
            ...values,
            [e.target.name]: e.target.value,
          });
    }

    const handleValidation = ()=>{
        const {password, phone, email, username} = values;
        
        if(username.length < 3){
            toast.error('Username Should Be Greater Than 3 Characters',toastOptions)
            return false
        }else if(password.length < 8){
            toast.error('Password Should Be Greater Than or Equal To 8 Characters',toastOptions)
            return false
        }else if(email === ''){
            toast.error('Email Is Required',toastOptions)
            return false
        }else if(/^[A-Za-z]+$/.test(username) === false){
            toast.error('Username Should Contain Alphabets Only',toastOptions)
            return false
        }else if(/^\d+$/.test(phone) === false){
            toast.error('Phone Number Contain Numbers Only',toastOptions)
            return false
        }
        return true
    }
  
  
  return (
    <>
        <FormContainer>
            <form onSubmit={(event)=> handleSubmit(event)}>
                <div className='brand'>
                <img src='' alt=''/>
                <h1>
                    snappy
                </h1>

                </div>
                <input 
                type='text'
                placeholder='Username' 
                name='username' 
                onChange={(e)=> handleChange(e)}
                />

                <input 
                type='email'
                placeholder='Email' 
                name='email' 
                onChange={(e)=> handleChange(e)}
                />

                <input 
                type='password'
                placeholder='Password' 
                name='password' 
                onChange={(e)=> handleChange(e)}
                />

                <input 
                type='phone'
                placeholder='Phone' 
                name='phone' 
                onChange={(e)=> handleChange(e)}
                />
                <div className='radio-container'>
                <label>
        <input
          type="radio"
          value="male"
          name='gender'
          onChange={(e)=> handleChange(e)}
        />
        Male
      </label>
      <label>
        <input
          type="radio"
          value="female"
          name='gender'
          onChange={(e)=> handleChange(e)}
        />
        Female
      </label>
      <label>
        <input
          type="radio"
          name='gender'
          value="other"
          onChange={(e)=> handleChange(e)}
        />
        Other
      </label>
                </div>
      
      <p>Selected Gender: {values.gender}</p>
      <div className='checkbox-container'>
            <p>How did you hear about this?</p>
            <label>
              <input
                type='checkbox'
                name='reference'
                value='LinkedIn'
                onChange={(e) => handleChange(e)}
              />
              LinkedIn
            </label>
            <label>
              <input
                type='checkbox'
                name='reference'
                value='Friends'
                onChange={(e) => handleChange(e)}
              />
              Friends
            </label>
            <label>
              <input
                type='checkbox'
                name='reference'
                value='Job Portal'
                onChange={(e) => handleChange(e)}
              />
              Job Portal
            </label>
            <label>
              <input
                type='checkbox'
                name='reference'
                value='Others'
                onChange={(e) => handleChange(e)}
              />
              Others
            </label>
          </div>
          <label htmlFor='city' className='city'>City:</label>
  <select
    id='city'
    name='city'
    value={values.city}
    onChange={(e) => handleChange(e)}
  >
    <option value=''>Select City</option>
    <option value='Mumbai'>Mumbai</option>
    <option value='Pune'>Pune</option>
    <option value='Ahmedabad'>Ahmedabad</option>
  </select>
  <label htmlFor='state' className='state'>State:</label>
  <select
    id='state'
    name='state'
    value={values.state}
    onChange={(e) => handleChange(e)}
  >
    <option value=''>Select state</option>
    <option value='Gujarat'>Gujarat</option>
    <option value='Maharashtra'>Maharashtra</option>
    <option value='Karnataka'>Karnataka</option>
  </select>
                 <button type="submit">
        {loading ? <Loader /> : 'Register'}
        </button>
                <span>Already have An Account ? <Link to='/login'>Login</Link> </span>
            </form>
        </FormContainer>
       <ToastContainer/>
    </>
    
  )
}

const FormContainer = styled.div`
height: 100vh;
width: 100vw;
display: flex;
flex-direction: column;
justify-content: center;
gap: 1rem;
align-items: center;
background-color: #131324;
.brand {
    display: flex;
    align-items: center;
    gap: 1rem;
    justify-content: center;
    h1 {
        color: white;
        text-transform: uppercase;
    }
}
.city {
    color: white;
        text-transform: uppercase;
}
.state {
    color: white;
        text-transform: uppercase;
}
form {
    display: flex;
    flex-direction: column;
    gap: 2rem;
    background-color: #00000076;
    border-radius: 2rem;
    padding: 3rem 5rem;
    input {
        background-color: transparent;
        padding: 1rem;
        border: 0.1rem solid #4e0eff;
        border-radius: 0.4rem;
        color: white;
        width: 100%;
        font-size: 1rem;
        &:focus{
            border: 0.1rem solid #997af0;
            outline: none;
        }
    }
    .checkbox-container {
      display: flex;
      flex-direction: row; /* Set labels to have a row direction */
      gap: 1rem; /* Adjust the gap as needed */
      margin-top: 0.5rem; /* Add margin for spacing if necessary */

      label {
        display: inline-block; /* Display labels inline */
        background-color: transparent;
        padding: 1rem;
        border: 0.1rem solid #4e0eff;
        border-radius: 0.4rem;
        color: white;
        font-size: 1rem;
        &:focus {
          border: 0.1rem solid #997af0;
          outline: none;
        }
      }
    }

    .radio-container {
      display: flex;
      flex-direction: row; /* Set labels to have a row direction */
      gap: 1rem; /* Adjust the gap as needed */
      margin-top: 0.5rem; /* Add margin for spacing if necessary */

      label {
        display: inline-block; /* Display labels inline */
        background-color: transparent;
        padding: 1rem;
        border: 0.1rem solid #4e0eff;
        border-radius: 0.4rem;
        color: white;
        font-size: 1rem;
        &:focus {
          border: 0.1rem solid #997af0;
          outline: none;
        }
      }
    }

    button {
        background-color: #997af0;
        padding: 1rem 2rem;
        border: none;
        border-radius: 0.4rem;
        color: white;
        font-weight: bold;
        cursor: pointer;
        border-radius: 0.4rem;
        font-size: 1rem;
        text-transform: uppercase;
        transition: 0.5s ease-in-out;
        &:hover {
            background-color: #4e0eff;
        }
    }
    p {
        background-color: #997af0;
        padding: 1rem 2rem;
        border: none;
        border-radius: 0.4rem;
        color: white;
        font-weight: bold;
        cursor: pointer;
        border-radius: 0.4rem;
        font-size: 1rem;
        text-transform: uppercase;
        transition: 0.5s ease-in-out;
        &:hover {
            background-color: #4e0eff;
        }
    }

    span {
        color: white;
        text-transform: uppercase;
        a {
            color: #4e0eff;
            text-decoration: none;
            font-weight: bold;
        }
    }
}
`
export default Register