import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate, useLocation } from 'react-router-dom';
import Loader from '../components/Loader'; // Number of users per page
import './Dashboard.css';
const ITEMS_PER_PAGE = 10; 

const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const location = useLocation();
  const userEdited = location.state && location.state.userEdited;
  const [users, setUsers] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  useEffect(()=>{
    if(!localStorage.getItem('chat-app-user')){
      navigate('/')
    }
  },[])

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  useEffect(() => {
    setLoading(true);
    if(!localStorage.getItem('chat-app-user')){
      navigate('/')
    }
    axios.get(`http://localhost:5000/api/users?page=${currentPage}&limit=${ITEMS_PER_PAGE}`)
      .then(response => {
        setLoading(false);
        if (response.data.status === false) {
          toast.error(response.data.message);
        } else {
          setUsers(response.data.devices); 
          setTotalPages(Math.ceil(response.data.totalCount / ITEMS_PER_PAGE));

        }
      })
      .catch(error => {
        setLoading(false);
        console.error(error);
        toast.error('An error occurred while fetching user data.');
      });


  }, [userEdited,currentPage]);

  const handleNextPage = () => {
    if(!localStorage.getItem('chat-app-user')){
      navigate('/')
    }
    // Ensure that the currentPage does not exceed the total number of pages
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };
  const navigate = useNavigate();
  const handleEdit = (userId) => {
    if(!localStorage.getItem('chat-app-user')){
      navigate('/')
    }
    // Implement the edit functionality based on the userId
    navigate(`/user/${userId}`);
  };
 
  const redirectToAddUser = () =>{
    navigate('/register');
  }

    const handleDelete = (userId) => {
      const confirmed = window.confirm('Are you sure you want to delete device?');
      if(confirmed){
        const storedToken = sessionStorage.getItem('authToken')
    const headers = {
      Authorization: storedToken,
    };
// Implement the delete functionality based on the userId
axios.delete(`http://localhost:5000/api/users/${userId}`,{headers})
.then(response => {
  console.log(response.data);
  setUsers(prevUsers => prevUsers.filter(user => user._id !== userId));
toast.success('device deleted successfully');
})
.catch(error => {
  console.error(error);
  toast.error('An error occurred while fetching user data.');
});
      }
      
    };
  

    
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const displayedUsers = users



  return (


    <div className="table-container">
    {
      loading ? (
        <Loader /> // Render the loader when loading is true
      ) :
      <div>
        <table className="table table-dark">
          <thead>
            <tr>
              <th scope="col">Email</th>
              <th scope="col">Username</th>
              <th scope="col">Phone</th>
              <th scope="col">City</th>
              <th scope="col">State</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            {displayedUsers.map(user => (
              <tr key={user.id}>
                <td>{user.email}</td>
                <td>{user.username}</td>
                <td>{user.phone}</td>
                <td>{user.city}</td>
                <td>{user.state}</td>
                <td>
                  <button onClick={() => handleEdit(user._id)}>Edit</button>
                  <button onClick={() => handleDelete(user._id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="pagination" style={{ 'display': 'flex', 'justifyContent': 'center', 'alignItems': 'center', 'marginTop': '20px' }}>
          <button disabled={currentPage === 1} onClick={goToPreviousPage}>
            Previous
          </button>
          <span>{currentPage} / {totalPages}</span>
          <button disabled={currentPage === totalPages} onClick={handleNextPage}>
            Next
          </button>
        </div>
        <button onClick={() => redirectToAddUser()}>Add Device</button>
      </div>
    }
    <ToastContainer />
  </div>
  

      
    
  );

};

export default Dashboard;