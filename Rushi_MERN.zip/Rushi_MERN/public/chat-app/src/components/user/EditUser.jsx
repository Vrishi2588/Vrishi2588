import axios from 'axios'
import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom';
export default function EditUser() {
  const storedToken = sessionStorage.getItem('authToken')
  const headers = {
    Authorization: storedToken,
  };
    const { id } = useParams();
    const navigate = useNavigate();
    const [user, setUser] = useState({});
    const [formData, setFormData] = useState({
      username: '',
      email: '',
      phone: '',
      city:'',
      state: '',
      reference:'',
    });
  
    useEffect(() => { const getUser = axios.get(`http://localhost:5000/api/users/${id}`,{headers})
    .then((data)=>{
      setUser(data.data.device);
      setFormData({
        username: data.data.device.username,
        email: data.data.device.email,
        phone: data.data.device.phone,
        city: data.data.device.city,
        state: data.data.device.state,
        reference: data.data.device.reference,

        // Set other form fields based on the fetched data
      });
    })
    .catch((err)=>{
        console.log(err)
    })},[id])

    const handleInputChange = event => {
      const { name, value } = event.target;
      setFormData(prevData => ({
        ...prevData,
        [name]: value,
      }));
    };

    const handleSubmit = event => {
      event.preventDefault();
  
      const confirmed = window.confirm('Are you sure you want to update the device details?');

  if (confirmed) {
    // Make API call to update user details
    axios.patch(`http://localhost:5000/api/users/${id}`, formData,{headers})
      .then(response => {
        // Handle success, e.g., show a success message
        navigate('/dashboard', { state: { userEdited: true } });
      })
      .catch(error => {
        console.error('Error updating user details:', error);
        // Handle error, e.g., show an error message
      });
  }
    };
   
  return (
    <form onSubmit={handleSubmit} style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      maxWidth: '400px', // Set the maximum width of the form
      margin: '0 auto', // Center the form horizontally
    }}>
      <div className="mb-3" style={{ width: '100%', textAlign: 'left' }}>
        <label htmlFor="exampleInputEmail1" className="form-label">
        userName
        </label>
        <input
          className="form-control"
          id="exampleInputEmail1"
          aria-describedby="emailHelp"
          name="username"
          value={formData.username}
          onChange={handleInputChange}
        />
      </div>
      <div className="mb-3" style={{ width: '100%', textAlign: 'left' }}>
        <label htmlFor="exampleInputPassword1" className="form-label">
        email
        </label>
        <input
        
          className="form-control"
          id="exampleInputPassword1"
          name="email"
          type='email'
          value={formData.email}
          onChange={handleInputChange}
        />
      </div>
      <div className="mb-3" style={{ width: '100%', textAlign: 'left' }}>
        <label htmlFor="exampleInputPassword1" className="form-label">
        Phone
        </label>
        <input
        
          className="form-control"
          id="exampleInputPassword1"
          name="phone"
          value={formData.phone}
          onChange={handleInputChange}
        />
      </div>
      <div className="mb-3" style={{ width: '100%', textAlign: 'left' }}>
        <label htmlFor="exampleInputPassword1" className="form-label">
        City
        </label>
        <input
        
          className="form-control"
          id="exampleInputPassword1"
          name="city"
          value={formData.city}
          onChange={handleInputChange}
        />
      </div>
      <div className="mb-3" style={{ width: '100%', textAlign: 'left' }}>
        <label htmlFor="exampleInputPassword1" className="form-label">
        State
        </label>
        <input
         
          className="form-control"
          id="exampleInputPassword1"
          name="state"
          value={formData.state}
          onChange={handleInputChange}
        />
      </div>
      <div className="mb-3" style={{ width: '100%', textAlign: 'left' }}>
        <label htmlFor="exampleInputPassword1" className="form-label">
        Reference
        </label>
        <input
         
          className="form-control"
          id="exampleInputPassword1"
          name="reference"
          value={formData.reference}
          onChange={handleInputChange}
        />
      </div>
      <button type="submit" className="btn btn-primary">
        Submit
      </button>
    </form>
  )
}
