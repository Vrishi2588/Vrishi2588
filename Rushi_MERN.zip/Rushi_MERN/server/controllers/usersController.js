const user_model = require('../models/userModel');
const bcrypt = require('bcrypt')
exports.login = async(req,res)=>{
    try{
        const {username, password} = req.body
        const user = await user_model.findOne({
            username
        });
        if(!user){
            return res.status(200).json({
                status: false,
                message: 'Incorrect Username'
            })
        }
        const isvalid_pass = await bcrypt.compare(password, user.password)
      if(!isvalid_pass){
        return res.status(200).json({
            status: false,
            message: 'Incorrect Password'
        })
      }
      delete user.password

            return res.status(200).json({
                status: true,
                user 
            })
    }catch(err){
        console.log(err)
    }
}

exports.register = async(req,res)=>{


    try{
        const {username, email, password, phone, city,state, reference} = req.body
        const email_check = await user_model.findOne({email})
        if(email_check){
            return res.status(200).json({
                status: false,
                message: 'Email Already Used'
            })
        }
        const hashed_password = await bcrypt.hash(password,10);
            const user = await user_model.create({
                email,username,password: hashed_password,phone, city,state, reference
            })
            delete user.password

            return res.status(200).json({
                status: true,
                user 
            })
    }catch(err){
        console.log(err)
        return res.status(200).json({
            status: false,
            message: 'Something Went Wrong' 
        })
    }
}




exports.get_all_device = async(req,res)=>{
    const options = {}
        const page = parseInt(req.query.page) || 1;
const perPage = parseInt(req.query.perPage) || 10;
    try{
        const totalCount = await user_model.countDocuments(options);
        const devices = await user_model.find(options).skip((page - 1) * perPage).limit(perPage); 
        if(devices.length <= 0){
            return res.status(200).json({
                status: false,
                message: `Records Not Found`
            })
        }
        return res.status(200).json({
            status: true,
            devices,
            totalCount
        })
    }catch(err){
        console.log(err)
        return res.status(200).json({
            status: false,
            message: 'Something Went Wrong'
        })
    }
        
}


exports.updateUser = async(req,res)=>{
    try{
        const update = await user_model.updateOne( { _id: req.params.user_id },
            {
              $set: req.body
            },)
        return res.status(200).json({
            status: true,
            message: 'User Updated Successfully'
        })
    }catch(err){
        console.log(err)
        return res.status(200).json({
            status: false,
            message: 'Something Went Wrong'
        })
    }
        
    }


    exports.delete_user =async(req,res)=>{
        if(!req.params.user_id){
            return res.status(200).json({
                success: false,
                message: 'User Id Is Required'
            })
        }
        const user = await user_model.findOne({_id: req.params.user_id})
        if(!user){
            return res.status(200).json({
                success: false,
                message: 'User Not Exist'
            })
        }
        try{
            user.remove()
            return res.status(200).json({
                success: true,
                message: "User Deleted Successfully"
            })
        }catch(err){
            return res.status(200).json({
                success: false,
                message: 'Something Went Wrong'
            })
        }
        
        }



        exports.get_user = async(req,res)=>{
            if (!req.params.user_id) {
                return res.status(200).json({
                    status: false,
                    message: 'Please Select The User To Get Details'
                })
              }
            try{
                const device = await user_model.findOne({
                    _id: req.params.user_id
                })
                if(!device){
                    return res.status(200).json({
                        status: false,
                        message: `User Details Not Exist Having Id: ${req.params.user_id}`
                    })
                }
                return res.status(200).json({
                    status: true,
                    device
                })
            }catch(err){
                console.log(err)
                return res.status(200).json({
                    status: false,
                    message: 'Something Went Wrong'
                })
            }
                
            }