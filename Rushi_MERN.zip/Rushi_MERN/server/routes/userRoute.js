const router = require('express').Router();
const {register, login,get_all_device,get_user, updateUser, delete_user } = require('../controllers/usersController')

router.post('/auth/register',register);

router.post('/auth/login',login);

router.get('/users',get_all_device);

router.get('/users/:user_id',get_user);

router.patch('/users/:user_id',updateUser);
router.delete('/users/:user_id',delete_user);
module.exports = router
